package web;

public class Usuario {
    private String dni_usu;
    private String nom_usu;
    private String ape_pat;
    private String ape_mat;
    private String contra_usu;
    private String correo_usu;
    private String direc_usu;
    private String telef_usu;

    // Métodos getters y setters
    public String getDni_usu() {
        return dni_usu;
    }

    public void setDni_usu(String dni_usu) {
        this.dni_usu = dni_usu;
    }

    public String getNom_usu() {
        return nom_usu;
    }

    public void setNom_usu(String nom_usu) {
        this.nom_usu = nom_usu;
    }

    public String getApe_pat() {
        return ape_pat;
    }

    public void setApe_pat(String ape_pat) {
        this.ape_pat = ape_pat;
    }

    public String getApe_mat() {
        return ape_mat;
    }

    public void setApe_mat(String ape_mat) {
        this.ape_mat = ape_mat;
    }

    public String getContra_usu() {
        return contra_usu;
    }

    public void setContra_usu(String contra_usu) {
        this.contra_usu = contra_usu;
    }

    public String getCorreo_usu() {
        return correo_usu;
    }

    public void setCorreo_usu(String correo_usu) {
        this.correo_usu = correo_usu;
    }

    public String getDirec_usu() {
        return direc_usu;
    }

    public void setDirec_usu(String direc_usu) {
        this.direc_usu = direc_usu;
    }

    public String getTelef_usu() {
        return telef_usu;
    }

    public void setTelef_usu(String telef_usu) {
        this.telef_usu = telef_usu;
    }
}
