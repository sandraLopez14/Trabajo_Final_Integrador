document.getElementById("iniciarSesionButton").addEventListener("click", function() {
    window.location.href = "sesion.html";
});

document.getElementById("Registrarse").addEventListener("click", function() {
    window.location.href = "registro.jsp";
});

